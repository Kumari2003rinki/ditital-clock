const time = document.getElementById('time');
const timeformat = document.getElementById('timeformat');

const showTime = () => {
    let date = new Date();

    let hr = date.getHours();
    let mints = date.getMinutes();
    let secs = date.getSeconds();

    // Convert hours to 12-hour format and determine AM/PM
    const amPm = hr >= 12 ? "PM" : "AM";
    hr = hr % 12 || 12; // Convert 0 to 12 for midnight

    // Format hours, minutes, and seconds
    hr = hr < 10 ? `0${hr}` : hr;
    mints = mints < 10 ? `0${mints}` : mints;
    secs = secs < 10 ? `0${secs}` : secs;

    // Update DOM elements
    time.innerText = `${hr} : ${mints} : ${secs}`;
    timeformat.innerText = amPm;
};

document.addEventListener('DOMContentLoaded', () => {
    setInterval(showTime, 1000);
});

// Initial call to display time immediately
showTime();
